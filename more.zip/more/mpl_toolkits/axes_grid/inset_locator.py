from mpl_toolkits.axes_grid1.inset_locator import InsetPosition, \
     AnchoredSizeLocator, \
     AnchoredZoomLocator, BboxPatch, BboxConnector, BboxConnectorPatch, \
     inset_axes, zoomed_inset_axes, mark_inset
